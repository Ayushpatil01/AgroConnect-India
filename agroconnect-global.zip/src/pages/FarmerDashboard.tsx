import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { PlusCircle, Package, Truck, DollarSign, MessageCircle, Info, CheckCircle2 } from 'lucide-react';
import ChatModal from '../components/ChatModal';
import Toast, { ToastType } from '../components/Toast';

export default function FarmerDashboard() {
  const { user, token } = useAuth();
  const [products, setProducts] = useState<any[]>([]);
  const [orders, setOrders] = useState<any[]>([]);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newProduct, setNewProduct] = useState({ name: '', quantity: '', quality: '', price: '', image: '' });
  const [chatUser, setChatUser] = useState<{ id: string, name: string } | null>(null);
  const [toast, setToast] = useState<{ message: string; type: ToastType; isVisible: boolean }>({
    message: '',
    type: 'success',
    isVisible: false
  });

  // Indian Crop Categories & Market Data
  const cropCategories: Record<string, { price: number, items: string[] }> = {
    'Fruits': { 
      price: 120, 
      items: ['Mango', 'Banana', 'Apple', 'Grapes', 'Orange', 'Papaya', 'Guava', 'Pomegranate', 'Watermelon'] 
    },
    'Vegetables': { 
      price: 40, 
      items: ['Potato', 'Onion', 'Tomato', 'Brinjal', 'Cabbage', 'Cauliflower', 'Carrot', 'Spinach', 'Okra', 'Peas'] 
    },
    'Grains': { 
      price: 35, 
      items: ['Rice', 'Wheat', 'Maize', 'Bajra', 'Jowar'] 
    },
    'Pulses': { 
      price: 110, 
      items: ['Tur', 'Chana', 'Moong', 'Urad'] 
    }
  };

  const [selectedCategory, setSelectedCategory] = useState<string>('Fruits');

  useEffect(() => {
    fetchProducts();
    fetchOrders();
  }, []);

  const fetchProducts = async () => {
    try {
      const res = await fetch(`/api/products?farmerId=${user?.id}`);
      const data = await res.json();
      setProducts(data);
    } catch (err) {
      console.error('Failed to fetch products');
    }
  };

  const fetchOrders = async () => {
    try {
      const res = await fetch('/api/orders', {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      setOrders(data);
    } catch (err) {
      console.error('Failed to fetch orders');
    }
  };

  const handleAddProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/products', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          name: newProduct.name,
          category: selectedCategory,
          quantity: Number(newProduct.quantity),
          quality: newProduct.quality,
          price: Number(newProduct.price),
          images: [newProduct.image || `https://images.unsplash.com/photo-1615485290382-441e4d019cb5?auto=format&fit=crop&q=80&w=400`],
          status: 'available'
        }),
      });
      if (res.ok) {
        setShowAddModal(false);
        setNewProduct({ name: '', quantity: '', quality: '', price: '', image: '' });
        fetchProducts();
        setToast({ message: 'Crop listed successfully! 🌾', type: 'success', isVisible: true });
      } else {
        const data = await res.json();
        throw new Error(data.message || 'Failed to add product');
      }
    } catch (err: any) {
      setToast({ message: err.message, type: 'error', isVisible: true });
    }
  };

  const updateOrderStatus = async (orderId: string, status: string) => {
    try {
      const res = await fetch(`/api/orders/${orderId}/status`, {
        method: 'PUT',
        headers: { 
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ status, location: user?.location }),
      });
      if (res.ok) {
        fetchOrders();
        setToast({ message: `Order status updated to ${status}! 🚛`, type: 'success', isVisible: true });
      } else {
        const data = await res.json();
        throw new Error(data.message || 'Failed to update status');
      }
    } catch (err: any) {
      setToast({ message: err.message, type: 'error', isVisible: true });
    }
  };

  const getSuggestedPrice = () => cropCategories[selectedCategory]?.price || null;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <Toast 
        message={toast.message} 
        type={toast.type} 
        isVisible={toast.isVisible} 
        onClose={() => setToast({ ...toast, isVisible: false })} 
      />

      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-black text-gray-900 tracking-tight">AgroConnect India</h1>
          <p className="text-gray-500 font-medium">Farmer Management Portal</p>
        </div>
        <button 
          onClick={() => setShowAddModal(true)}
          className="bg-green-600 text-white px-6 py-2.5 rounded-xl font-bold flex items-center space-x-2 hover:bg-green-700 transition shadow-lg shadow-green-100"
        >
          <PlusCircle className="h-5 w-5" />
          <span>List New Crop</span>
        </button>
      </div>

      {/* Stats Section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="glass-card p-6 rounded-2xl flex items-center space-x-4">
          <div className="bg-green-100 p-3 rounded-full"><Package className="h-6 w-6 text-green-600" /></div>
          <div>
            <p className="text-xs text-gray-500 font-bold uppercase tracking-wider">Storage Capacity</p>
            <p className="text-3xl font-black text-gray-900">{products.length} Items</p>
          </div>
        </div>
        <div className="glass-card p-6 rounded-2xl flex items-center space-x-4">
          <div className="bg-blue-100 p-3 rounded-full"><Truck className="h-6 w-6 text-blue-600" /></div>
          <div>
            <p className="text-xs text-gray-500 font-bold uppercase tracking-wider">Active Transport</p>
            <p className="text-3xl font-black text-gray-900">{orders.filter(o => o.status === 'Shipped' || o.status === 'In Transit').length}</p>
          </div>
        </div>
        <div className="glass-card p-6 rounded-2xl flex items-center space-x-4">
          <div className="bg-yellow-100 p-3 rounded-full"><DollarSign className="h-6 w-6 text-yellow-600" /></div>
          <div>
            <p className="text-xs text-gray-500 font-bold uppercase tracking-wider">Revenue (INR)</p>
            <p className="text-3xl font-black text-gray-900">
              ₹{orders.filter(o => o.status === 'Delivered').reduce((acc, o) => acc + o.totalPrice, 0).toLocaleString()}
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Products List */}
        <div className="glass-card rounded-2xl overflow-hidden min-h-[400px]">
          <div className="px-6 py-4 border-b border-gray-100 bg-white/50 flex justify-between items-center">
            <h2 className="text-lg font-bold text-gray-900">My Inventory</h2>
            <span className="text-[10px] bg-gray-100 px-2 py-0.5 rounded-full font-bold text-gray-400 uppercase">Live Stock</span>
          </div>
          <ul className="divide-y divide-gray-100">
            {products.length === 0 ? (
              <li className="px-6 py-12 text-gray-500 text-center">
                <Package className="h-12 w-12 mx-auto mb-3 opacity-20" />
                <p>No crops listed. Start by listing your produce.</p>
              </li>
            ) : (
              products.map(p => (
                <li key={p.id} className="px-6 py-5 flex items-center space-x-4 hover:bg-white/30 transition-colors">
                  <img src={p.images[0]} alt={p.name} className="h-14 w-14 object-cover rounded-xl shadow-sm" referrerPolicy="no-referrer" />
                  <div className="flex-1">
                    <h3 className="text-md font-bold text-gray-900">{p.name}</h3>
                    <p className="text-[11px] text-gray-400 font-bold uppercase tracking-tighter">{p.category || 'Produce'}</p>
                    <p className="text-sm text-gray-500">{p.quantity} kg • {p.quality}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-md font-black text-green-600 font-mono">₹{p.price}/kg</p>
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wide ${
                      p.status === 'available' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                    }`}>
                      {p.status.replace('_', ' ')}
                    </span>
                  </div>
                </li>
              ))
            )}
          </ul>
        </div>

        {/* Orders List */}
        <div className="glass-card rounded-2xl overflow-hidden min-h-[400px]">
          <div className="px-6 py-4 border-b border-gray-100 bg-white/50">
            <h2 className="text-lg font-bold text-gray-900">Market Orders</h2>
          </div>
          <ul className="divide-y divide-gray-100">
            {orders.length === 0 ? (
              <li className="px-6 py-12 text-gray-500 text-center">
                <Truck className="h-12 w-12 mx-auto mb-3 opacity-20" />
                <p>Waiting for buyers to place orders...</p>
              </li>
            ) : (
              orders.map(o => (
                <li key={o.id} className="px-6 py-5">
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex space-x-3">
                      <div className="bg-gray-100 h-10 w-10 rounded-lg flex items-center justify-center font-bold text-gray-500">
                        {o.productName.charAt(0)}
                      </div>
                      <div>
                        <h3 className="text-md font-bold text-gray-900">{o.productName}</h3>
                        <p className="text-xs text-gray-500">Buyer: <span className="font-bold">{o.otherPartyName}</span></p>
                        <p className="text-[10px] text-gray-400">{o.otherPartyLocation}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-black text-gray-900">₹{o.totalPrice.toLocaleString()}</p>
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                        o.status === 'Delivered' ? 'bg-green-100 text-green-800' : 
                        o.status === 'Shipped' ? 'bg-blue-100 text-blue-800' : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {o.status}
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between pt-2 border-t border-gray-50">
                    <div className="flex flex-col space-y-1">
                      {o.transporterName ? (
                        <p className="text-[10px] text-blue-600 font-bold">🚛 Transporter: {o.transporterName}</p>
                      ) : (
                        <p className="text-[10px] text-gray-400 font-bold italic">Waiting for transporter...</p>
                      )}
                      <div className="flex space-x-2">
                         {o.status === 'Pending' && (
                          <p className="text-[10px] text-gray-400">Logistics dispatch pending</p>
                        )}
                        {o.status === 'Processing' && o.transporterId && (
                          <button 
                            onClick={() => updateOrderStatus(o.id, 'Shipped')}
                            className="text-[11px] font-bold bg-green-600 text-white px-4 py-1.5 rounded-full hover:bg-green-700 shadow-sm"
                          >
                            Mark as Shipped
                          </button>
                        )}
                      </div>
                    </div>
                    <button 
                      onClick={() => setChatUser({ id: o.buyerId, name: o.otherPartyName })}
                      className="flex items-center space-x-1.5 text-xs text-gray-600 hover:text-green-600 font-bold"
                    >
                      <MessageCircle className="h-4 w-4" />
                      <span>Contact Buyer</span>
                    </button>
                  </div>
                </li>
              ))
            )}
          </ul>
        </div>
      </div>

      {/* Add Product Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl max-w-lg w-full p-8 shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <h2 className="text-3xl font-black text-gray-900 mb-2">New Crop Listing</h2>
            <p className="text-gray-500 text-sm mb-6">Connect with buyers and transporters across India.</p>
            
            <form onSubmit={handleAddProduct} className="space-y-6">
              <div>
                <label className="block text-[11px] font-bold text-gray-400 uppercase tracking-widest mb-3 text-center">Step 1: Select Category</label>
                <div className="grid grid-cols-4 gap-2">
                  {Object.keys(cropCategories).map(cat => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => {
                        setSelectedCategory(cat);
                        setNewProduct({ ...newProduct, name: '' });
                      }}
                      className={`py-3 rounded-xl font-bold text-xs transition-all border-2 ${
                        selectedCategory === cat 
                          ? 'bg-green-600 text-white border-green-600 shadow-md' 
                          : 'bg-gray-50 text-gray-500 border-gray-100 hover:border-green-200'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-gray-400 uppercase tracking-widest mb-3 text-center">Step 2: Choose Item</label>
                <div className="flex flex-wrap gap-2 justify-center">
                  {cropCategories[selectedCategory].items.map(item => (
                    <button
                      key={item}
                      type="button"
                      onClick={() => setNewProduct({ ...newProduct, name: item })}
                      className={`px-4 py-2 rounded-lg text-xs font-medium transition-all border ${
                        newProduct.name === item 
                          ? 'bg-green-100 text-green-700 border-green-300 scale-105 shadow-sm' 
                          : 'bg-white text-gray-600 border-gray-200 hover:bg-gray-50'
                      }`}
                    >
                      {item}
                    </button>
                  ))}
                </div>
              </div>

              {newProduct.name && (
                <div className="bg-green-50 p-4 rounded-2xl flex items-start space-x-3 text-green-700 text-xs border border-green-100">
                  <Info className="h-4 w-4 mt-0.5 flex-shrink-0" />
                  <div>
                    <span className="font-bold">Market Insight:</span>
                    <p className="mt-0.5">Average prices for <span className="font-bold">{newProduct.name}</span> in {selectedCategory} are around <span className="font-bold">₹{getSuggestedPrice()}/kg</span> today.</p>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[11px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">Quantity (kg)</label>
                  <input type="number" required min="1" className="w-full border-gray-200 border rounded-xl p-3 focus:ring-green-500 focus:border-green-500 bg-gray-50 text-sm" value={newProduct.quantity} onChange={e => setNewProduct({...newProduct, quantity: e.target.value})} />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">Price (₹/kg)</label>
                  <input type="number" step="1" required min="1" className="w-full border-gray-200 border rounded-xl p-3 focus:ring-green-500 focus:border-green-500 bg-gray-50 text-sm" value={newProduct.price} onChange={e => setNewProduct({...newProduct, price: e.target.value})} />
                </div>
              </div>
              
              <div>
                <label className="block text-[11px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">Quality / Variety</label>
                <input type="text" placeholder="e.g. Organic, Grade A, Desi" required className="w-full border-gray-200 border rounded-xl p-3 focus:ring-green-500 focus:border-green-500 bg-gray-50 text-sm" value={newProduct.quality} onChange={e => setNewProduct({...newProduct, quality: e.target.value})} />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-gray-400 uppercase tracking-widest mb-1.5">Photo of Item (Image URL)</label>
                <input 
                  type="url" 
                  placeholder="https://example.com/crop-photo.jpg" 
                  className="w-full border-gray-200 border rounded-xl p-3 focus:ring-green-500 focus:border-green-500 bg-gray-50 text-sm" 
                  value={newProduct.image} 
                  onChange={e => setNewProduct({...newProduct, image: e.target.value})} 
                />
                <p className="text-[10px] text-gray-400 mt-1 italic">Optional: Provide a link to your crop photo for trust.</p>
              </div>

              <div className="flex justify-end space-x-3 pt-2">
                <button type="button" onClick={() => setShowAddModal(false)} className="px-6 py-3 rounded-xl text-gray-400 font-bold hover:bg-gray-100 transition text-sm">Discard</button>
                <button type="submit" className="px-8 py-3 bg-green-600 text-white rounded-xl font-bold hover:bg-green-700 shadow-xl shadow-green-100 transition text-sm">Post Listing</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Chat Interface */}
      {chatUser && (
        <ChatModal 
          otherUserId={chatUser.id} 
          otherUserName={chatUser.name} 
          onClose={() => setChatUser(null)} 
        />
      )}
    </div>
  );
}
