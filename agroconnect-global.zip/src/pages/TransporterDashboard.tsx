import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { Truck, MapPin, Package, CheckCircle2, MessageCircle, DollarSign, Clock } from 'lucide-react';
import ChatModal from '../components/ChatModal';
import Toast, { ToastType } from '../components/Toast';

export default function TransporterDashboard() {
  const { user, token } = useAuth();
  const [orders, setOrders] = useState<any[]>([]);
  const [chatUser, setChatUser] = useState<{ id: string, name: string } | null>(null);
  const [toast, setToast] = useState<{ message: string; type: ToastType; isVisible: boolean }>({
    message: '',
    type: 'success',
    isVisible: false
  });

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    try {
      const res = await fetch('/api/orders', {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      setOrders(data);
    } catch (err) {
      console.error('Failed to fetch orders');
    }
  };

  const acceptJob = async (orderId: string) => {
    try {
      const res = await fetch(`/api/orders/${orderId}/accept-transport`, {
        method: 'PUT',
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        setToast({ message: 'Transport job accepted! 🚛', type: 'success', isVisible: true });
        fetchOrders();
      } else {
        const data = await res.json();
        throw new Error(data.message || 'Failed to accept job');
      }
    } catch (err: any) {
      setToast({ message: err.message, type: 'error', isVisible: true });
    }
  };

  const updateStatus = async (orderId: string, status: string) => {
    try {
      const res = await fetch(`/api/orders/${orderId}/status`, {
        method: 'PUT',
        headers: { 
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ status, location: user?.location }),
      });
      if (res.ok) {
        fetchOrders();
        setToast({ message: `Status updated to ${status}! ✅`, type: 'success', isVisible: true });
      } else {
        const data = await res.json();
        throw new Error(data.message || 'Failed to update status');
      }
    } catch (err: any) {
      setToast({ message: err.message, type: 'error', isVisible: true });
    }
  };

  const myAcceptedJobs = orders.filter(o => o.transporterId === user?.id);
  const availableJobs = orders.filter(o => !o.transporterId && o.status === 'Pending');
  const deliveredJobs = myAcceptedJobs.filter(o => o.status === 'Delivered');
  const revenue = deliveredJobs.reduce((acc, o) => acc + (o.totalPrice * 0.1), 0); // Assuming 10% transport fee

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <Toast 
        message={toast.message} 
        type={toast.type} 
        isVisible={toast.isVisible} 
        onClose={() => setToast({ ...toast, isVisible: false })} 
      />

      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-black text-gray-900 tracking-tight">Logistics Hub</h1>
          <p className="text-gray-500 font-medium tracking-wide">Manage agri-transport requests across India</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="glass-card p-6 rounded-2xl flex items-center space-x-4">
          <div className="bg-blue-100 p-3 rounded-full"><Truck className="h-6 w-6 text-blue-600" /></div>
          <div>
            <p className="text-xs text-gray-500 font-bold uppercase tracking-wider">Active Deliveries</p>
            <p className="text-3xl font-black text-gray-900">{myAcceptedJobs.filter(o => o.status !== 'Delivered').length}</p>
          </div>
        </div>
        <div className="glass-card p-6 rounded-2xl flex items-center space-x-4">
          <div className="bg-green-100 p-3 rounded-full"><CheckCircle2 className="h-6 w-6 text-green-600" /></div>
          <div>
            <p className="text-xs text-gray-500 font-bold uppercase tracking-wider">Completed</p>
            <p className="text-3xl font-black text-gray-900">{deliveredJobs.length}</p>
          </div>
        </div>
        <div className="glass-card p-6 rounded-2xl flex items-center space-x-4">
          <div className="bg-yellow-100 p-3 rounded-full"><DollarSign className="h-6 w-6 text-yellow-600" /></div>
          <div>
            <p className="text-xs text-gray-500 font-bold uppercase tracking-wider">My Earnings</p>
            <p className="text-3xl font-black text-gray-900">₹{revenue.toLocaleString()}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Available Jobs */}
        <div className="glass-card rounded-2xl overflow-hidden min-h-[400px]">
          <div className="px-6 py-4 border-b border-gray-100 bg-white/50 flex justify-between items-center">
            <h2 className="text-lg font-bold text-gray-900">Nearby Transport Jobs</h2>
            <span className="bg-blue-100 text-blue-700 text-[10px] font-black uppercase px-2 py-0.5 rounded-full">Explore</span>
          </div>
          <ul className="divide-y divide-gray-100">
            {availableJobs.length === 0 ? (
              <li className="px-6 py-12 text-gray-500 text-center">
                <Clock className="h-12 w-12 mx-auto mb-3 opacity-20" />
                <p>No new jobs available at the moment.</p>
              </li>
            ) : (
              availableJobs.map(o => (
                <li key={o.id} className="px-6 py-5 hover:bg-white/30 transition-colors">
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex space-x-3">
                      <div className="bg-gray-100 h-10 w-10 rounded-lg flex items-center justify-center font-bold text-gray-500">
                        {o.productName.charAt(0)}
                      </div>
                      <div>
                        <h3 className="text-md font-bold text-gray-900">{o.productName}</h3>
                        <div className="flex items-center text-[11px] text-gray-500">
                           <MapPin className="h-3 w-3 mr-1 text-green-500" />
                           {o.farmerLocation} → {o.buyerLocation}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-xs font-bold text-gray-400">Total Load</p>
                      <p className="text-sm font-black text-gray-900">{o.quantity}kg</p>
                    </div>
                  </div>
                  <button 
                    onClick={() => acceptJob(o.id)}
                    className="w-full bg-blue-600 text-white py-2 rounded-xl font-bold hover:bg-blue-700 transition shadow-lg shadow-blue-100 flex items-center justify-center space-x-2"
                  >
                    <Truck className="h-4 w-4" />
                    <span>Accept Transport Job</span>
                  </button>
                </li>
              ))
            )}
          </ul>
        </div>

        {/* My Deliveries */}
        <div className="glass-card rounded-2xl overflow-hidden min-h-[400px]">
          <div className="px-6 py-4 border-b border-gray-100 bg-white/50 flex justify-between items-center">
            <h2 className="text-lg font-bold text-gray-900">My Deliveries</h2>
            <span className="bg-green-100 text-green-700 text-[10px] font-black uppercase px-2 py-0.5 rounded-full">Tracking</span>
          </div>
          <ul className="divide-y divide-gray-100">
            {myAcceptedJobs.length === 0 ? (
              <li className="px-6 py-12 text-gray-500 text-center">
                <Package className="h-12 w-12 mx-auto mb-3 opacity-20" />
                <p>You haven't accepted any jobs yet.</p>
              </li>
            ) : (
              myAcceptedJobs.map(o => (
                <li key={o.id} className="px-6 py-5">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-md font-bold text-gray-900">{o.productName}</h3>
                      <p className="text-xs text-gray-500">Buyer: <span className="text-gray-900 font-bold">{o.buyerName}</span></p>
                    </div>
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                      o.status === 'Delivered' ? 'bg-green-100 text-green-800' : 
                      o.status === 'Shipped' ? 'bg-blue-100 text-blue-800' : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {o.status}
                    </span>
                  </div>

                  {o.status !== 'Delivered' && (
                    <div className="flex gap-2">
                       {o.status === 'Processing' && (
                        <p className="text-xs text-gray-500 italic mb-2">Waiting for farmer to mark as Shipped...</p>
                      )}
                      {o.status === 'Shipped' && (
                        <button 
                          onClick={() => updateStatus(o.id, 'In Transit')}
                          className="flex-1 bg-blue-600 text-white py-2 rounded-xl font-bold text-xs hover:bg-blue-700 transition"
                        >
                          Out for Delivery
                        </button>
                      )}
                      {o.status === 'In Transit' && (
                        <button 
                          onClick={() => updateStatus(o.id, 'Delivered')}
                          className="flex-1 bg-green-600 text-white py-2 rounded-xl font-bold text-xs hover:bg-green-700 transition"
                        >
                          Confirm Delivery
                        </button>
                      )}
                      <button 
                        onClick={() => setChatUser({ id: o.farmerId, name: o.farmerName })}
                        className="bg-white border p-2 rounded-xl"
                        title="Chat with Farmer"
                      >
                        <MessageCircle className="h-4 w-4" />
                      </button>
                    </div>
                  )}
                </li>
              ))
            )}
          </ul>
        </div>
      </div>

      {chatUser && (
        <ChatModal 
          otherUserId={chatUser.id} 
          otherUserName={chatUser.name} 
          onClose={() => setChatUser(null)} 
        />
      )}
    </div>
  );
}
